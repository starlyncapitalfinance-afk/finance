/* ============ UI: shell, router, screens, collection report + PDF ============ */
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const toast = (m) => { const t = $('#toast'); t.textContent = m; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2200); };

const NAV = [
  { group: 'overview', items: [['#/dashboard', 'dashboard'], ['#/eod', 'eod']] },
  { group: 'loan', items: [['#/jlg/new', 'newLoan'], ['#/jlg/records', 'loanRecords']] },
  { group: 'center', items: [['#/center/new', 'newCenter'], ['#/center/records', 'centerRecords']] },
  { group: 'reports', items: [['#/reports/staff', 'staffCollection']] },
  { group: 'account', items: [['#/users', 'users', true], ['#/profile', 'profile']] },
];

const UI = {
  mount() {
    document.body.innerHTML =
      `<div id="app"></div><div id="layer"></div><div id="toast"></div>`;
    window.addEventListener('hashchange', () => this.refresh());
    // close the mobile drawer when tapping outside the sidebar
    document.addEventListener('click', (e) => {
      const app = $('#app');
      if (app && app.classList.contains('open') &&
          !e.target.closest('.side') && !e.target.closest('[data-act="menu"]')) {
        app.classList.remove('open');
      }
    });
    this.refresh();
  },

  syncBadge() {
    const st = Sync.state, p = Sync.pending();
    const label = { local: 'Local', syncing: 'Syncing…', ok: 'Synced', offline: 'Offline', error: 'Sync error', auth: 'Sign in again' }[st] || st;
    return `<span class="badge ${st}">${label}${p ? ' · ' + p : ''}</span>`;
  },

  refresh() {
    if (!Core.Auth.signedIn) return this.renderAuth();
    const app = $('#app');
    const hash = location.hash || '#/dashboard';
    app.innerHTML = `
      <aside class="side">
        <div class="logo"><img src="icon-192.png" alt="logo"/></div>
        <nav class="nav">${NAV.map((g) => `
          <div class="grp">${t(g.group)}</div>
          ${g.items.filter((it) => !it[2] || Core.Auth.isAdmin).map(([h, k]) => `<a href="${h}" class="navlink ${hash.startsWith(h) ? 'active' : ''}">${t(k)}</a>`).join('')}
        `).join('')}</nav>
        <div class="side-foot">
          <button class="lang" data-act="lang">${t('lang')}</button>
          <div class="who">${esc(Core.Auth.user.name)}${Core.Auth.isAdmin ? ' · admin' : ''}</div>
          <button class="logout" data-act="logout">⎋ ${t('logout')}</button>
        </div>
      </aside>
      <main class="main">
        <header class="top">
          <button class="burger" data-act="menu">☰</button>
          <div class="title">${t('appName')}</div>
          ${this.syncBadge()}
        </header>
        <section id="view"></section>
      </main>`;
    app.querySelectorAll('[data-act]').forEach((b) => b.onclick = () => this.act(b.dataset.act));
    this.route(hash);
  },

  act(a) {
    if (a === 'logout') { if (confirm('Log out?')) Sync.signOut(); }
    if (a === 'lang') { setLang(getLang() === 'en' ? 'ta' : 'en'); this.refresh(); }
    if (a === 'menu') { $('#app').classList.toggle('open'); }
  },

  chrome() { const b = $('.badge'); if (b) b.outerHTML = this.syncBadge(); },

  route(hash) {
    $('#app').classList.remove('open');
    const v = $('#view'); if (!v) return;
    if (hash.startsWith('#/jlg/new')) return this.jlgNew(v);
    if (hash.startsWith('#/jlg/records')) return this.jlgRecords(v);
    if (hash.startsWith('#/center/new')) return this.centerNew(v);
    if (hash.startsWith('#/center/records')) return this.centerRecords(v);
    if (hash.startsWith('#/users')) return this.usersView(v);
    if (hash.startsWith('#/profile')) return this.profileView(v);
    if (hash.startsWith('#/dashboard')) return this.dashboardView(v);
    if (hash.startsWith('#/eod')) return this.eodView(v);
    if (hash.startsWith('#/reports/staff')) return this.staffCollectionView(v);
    location.hash = '#/dashboard';
  },

  /* ---------------- auth ---------------- */
  renderAuth() {
    const def = window.DEFAULT_SERVER || '';
    $('#app').innerHTML = `
      <div class="auth">
        <div class="card auth-card">
          <img class="auth-logo" src="icon-192.png"/>
          <h1>${t('appName')}</h1>
          <div class="seg"><button data-m="login" class="on">${t('login')}</button><button data-m="setup">${t('setup')}</button></div>
          <label>${t('serverUrl')}</label><input id="a-url" value="${esc(def)}"/>
          <div id="a-name-wrap" style="display:none"><label>${t('fullName')}</label><input id="a-name"/></div>
          <label>${t('username')}</label><input id="a-user"/>
          <label>${t('password')}</label><input id="a-pass" type="password"/>
          <div id="a-err" class="err"></div>
          <button id="a-go" class="btn-accent">${t('login')}</button>
        </div>
      </div>`;
    let mode = 'login';
    const segs = $('#app').querySelectorAll('.seg button');
    segs.forEach((b) => b.onclick = () => {
      mode = b.dataset.m; segs.forEach((x) => x.classList.toggle('on', x === b));
      $('#a-name-wrap').style.display = mode === 'setup' ? '' : 'none';
      $('#a-go').textContent = mode === 'setup' ? t('setup') : t('login');
    });
    $('#a-go').onclick = async () => {
      const url = $('#a-url').value, u = $('#a-user').value, p = $('#a-pass').value, nm = ($('#a-name') || {}).value || u;
      $('#a-err').textContent = '';
      try {
        if (!url) throw new Error('Server URL required');
        if (mode === 'setup') await Sync.setup(url, nm, u, p); else await Sync.signIn(url, u, p);
        this.refresh();
      } catch (e) { $('#a-err').textContent = (e.message || 'Failed'); }
    };

    // if the server already has an admin, hide "Set up server" (only Sign in)
    if (def) Sync.status(def).then((st) => {
      if (st && st.hasAdmin) {
        const setupBtn = $('#app').querySelector('.seg button[data-m="setup"]');
        if (setupBtn) setupBtn.style.display = 'none';
        const seg = $('#app').querySelector('.seg'); if (seg) seg.style.display = 'none';
      }
    }).catch(() => {});
  },

  /* ---------------- JLG new ---------------- */
  jlgNew(v) {
    const centers = Core.all('centers').sort((a, b) => (a.centerNumber > b.centerNumber ? -1 : 1));
    const today = Core.fmtDMY(new Date());
    const todayISO = new Date().toISOString().slice(0,10);
    const rels = ['Wife', 'Husband', 'Son', 'Daughter', 'Father', 'Mother', 'Brother', 'Sister', 'Other'];
    const aadBoxes = Array.from({ length: 12 }, (_, i) =>
      `<input class="aad" data-i="${i}" maxlength="1" inputmode="numeric"${i === 4 || i === 8 ? ' style="margin-left:8px"' : ''}/>`).join('');
    v.innerHTML = `
      <div class="formhead">
        <h2>${t('newLoan')}</h2>
        <div class="hbtns">
          <button id="f-scanbtn" class="mini">📷 ${t('scan')}</button>
          <button id="f-sample" class="mini" style="background:#059669">${t('sample')}</button>
        </div>
      </div>
      <input type="file" id="f-scan" accept="image/*" capture="environment" hidden/>
      <div class="card form">
        <label>${t('center')}</label>
        <select id="f-center">${centers.length ? centers.map((c) => `<option value="${esc(c.id)}">${esc(c.centerNumber)} — ${esc(c.centerName)}</option>`).join('') : `<option value="">(no centers — create one first)</option>`}</select>
        <label>${t('customer')}</label><input id="f-member"/>
        <label>${t('aadhaar')}</label>
        <div class="aadwrap">${aadBoxes}</div>
        <label>${t('address')}</label><textarea id="f-address"></textarea>
        <label>${t('loanDate')}</label><input id="f-date" type="date" value="${todayISO}"/>
        <label>${t('loanAmt')}</label><input id="f-amt" inputmode="decimal"/>
        <label>${t('interest')}</label><input id="f-rate" inputmode="decimal"/>
        <label>${t('tenure')}</label><input id="f-tenure" inputmode="numeric"/>
        <label>${t('emi')}</label><input id="f-emi" readonly class="ro"/>
        <label>${t('nominee')}</label><input id="f-nom"/>
        <label>${t('relation')}</label>
        <select id="f-rel">${rels.map((r) => `<option>${r}</option>`).join('')}</select>
        <div class="row-btn"><button id="f-save" class="btn-accent">${t('save')}</button><button id="f-clear" class="btn-ghost">${t('clear')}</button></div>
      </div>`;

    // aadhaar 12-box auto-advance
    const boxes = [...v.querySelectorAll('.aad')];
    boxes.forEach((b, i) => {
      b.oninput = () => {
        b.value = b.value.replace(/\D/g, '').slice(0, 1);
        if (b.value && i < 11) boxes[i + 1].focus();
      };
      b.onkeydown = (e) => {
        if (e.key === 'Backspace' && !b.value && i > 0) boxes[i - 1].focus();
      };
      b.onpaste = (e) => {
        const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 12);
        if (d) { e.preventDefault(); d.split('').forEach((ch, k) => { if (boxes[k]) boxes[k].value = ch; }); boxes[Math.min(d.length, 11)].focus(); }
      };
    });
    const readAad = () => { const d = boxes.map((b) => b.value).join(''); return d ? d.replace(/(\d{4})(\d{4})(\d{0,4})/, (m, a, b2, c) => [a, b2, c].filter(Boolean).join(' ')) : ''; };
    const setAad = (val) => { const d = String(val || '').replace(/\D/g, '').slice(0, 12).split(''); boxes.forEach((b, k) => b.value = d[k] || ''); };

    const recalc = () => {
      const emi = Core.weeklyEmi(Core.num($('#f-amt').value), Core.num($('#f-rate').value), parseInt($('#f-tenure').value || 0, 10) || 0);
      $('#f-emi').value = emi > 0 ? '₹ ' + Core.inr(emi) + ' (Week)' : '';
    };
    ['f-amt', 'f-rate', 'f-tenure'].forEach((id) => $('#' + id).oninput = recalc);
    $('#f-clear').onclick = () => this.jlgNew(v);

    $('#f-sample').onclick = () => {
      if (centers.length) $('#f-center').value = centers[0].id;
      $('#f-member').value = 'Kannan Subramaniam';
      setAad('123456789012');
      $('#f-address').value = 'No 45, Bharathi Nagar, Avadi, Chennai - 600054';
      $('#f-amt').value = '50000'; $('#f-rate').value = '5'; $('#f-tenure').value = '50';
      $('#f-nom').value = 'Kamala Kannan'; $('#f-rel').value = 'Wife';
      recalc();
    };

    $('#f-scanbtn').onclick = () => $('#f-scan').click();
    $('#f-scan').onchange = async (e) => {
      const file = e.target.files[0]; if (!file) return;
      const btn = $('#f-scanbtn'); const old = btn.textContent; btn.textContent = '⏳'; btn.disabled = true;
      try {
        const url = URL.createObjectURL(file);
        const r = await OCR.scan(url); URL.revokeObjectURL(url);
        if (r.name) $('#f-member').value = r.name;
        if (r.aadhaar) setAad(r.aadhaar);
        if (r.address) $('#f-address').value = r.address;
        toast((r.name || r.aadhaar || r.address) ? 'Filled — please verify' : 'Could not read card');
      } catch (err) { toast('Scan failed: ' + (err.message || err)); }
      finally { btn.textContent = old; btn.disabled = false; }
    };

    $('#f-save').onclick = () => {
      const cid = $('#f-center').value, c = Core.get('centers', cid);
      if (!c) return toast('Select a center');
      if (!$('#f-member').value.trim()) return toast('Customer name required');
      const emi = Core.weeklyEmi(Core.num($('#f-amt').value), Core.num($('#f-rate').value), parseInt($('#f-tenure').value || 0, 10) || 0);
      const loanDate = Core.parseDMY($('#f-date').value);
      const weekday = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][loanDate.getDay()];
      Core.saveRec('loans', {
        loanNumber: Core.nextLoanNumber(), loanDate: (function(x){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(x);return m?`${m[3]}-${m[2]}-${m[1]}`:x;})($('#f-date').value),
        centerNumber: c.centerNumber, centerName: c.centerName,
        member: $('#f-member').value.trim(), aadhaar: readAad(),
        address: $('#f-address').value.trim(), loanAmt: Core.num($('#f-amt').value),
        interestRate: Core.num($('#f-rate').value), tenure: parseInt($('#f-tenure').value || 0, 10) || 0,
        collectionDay: weekday, emi, freq: 'Week',
        nomineeName: $('#f-nom').value.trim(), nomineeRelation: $('#f-rel').value, status: 'Active',
      });
      toast('Loan saved'); this.jlgNew(v);
    };
  },

  /* ---------------- JLG records ---------------- */
  jlgRecords(v) {
    const centers = Core.all('centers');
    const st = this._jf || (this._jf = { name: '', loanNo: '', aadhaar: '', center: '', day: '', status: '', amtMin: '', amtMax: '', page: 1 });
    const PER = 12;
    let current = [];
    const draw = () => {
      let rows = Core.all('loans').sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      rows = rows.filter((r) =>
        (!st.name || (r.member || '').toLowerCase().includes(st.name.toLowerCase())) &&
        (!st.loanNo || (r.loanNumber || '').toLowerCase().includes(st.loanNo.toLowerCase())) &&
        (!st.aadhaar || (r.aadhaar || '').replace(/\D/g,'').includes(st.aadhaar.replace(/\D/g,''))) &&
        (!st.center || r.centerNumber === st.center) &&
        (!st.day || r.collectionDay === st.day) &&
        (!st.status || r.status === st.status) &&
        (!st.amtMin || Core.num(r.loanAmt) >= Core.num(st.amtMin)) &&
        (!st.amtMax || Core.num(r.loanAmt) <= Core.num(st.amtMax)));
      current = rows;
      const pages = Math.max(1, Math.ceil(rows.length / PER));
      if (st.page > pages) st.page = pages;
      const slice = rows.slice((st.page - 1) * PER, st.page * PER);
      $('#jlg-count').textContent = `(${rows.length})`;
      $('#jlg-body').innerHTML = slice.length ? slice.map((r) => `
        <tr data-detail="${esc(r.id)}">
          <td>${esc(r.loanNumber)}</td><td>${esc(r.member)}</td><td>${esc(r.centerNumber || '')}</td>
          <td>${esc(r.aadhaar || '')}</td><td class="num">${Core.inr(Core.num(r.loanAmt))}</td>
          <td class="num">${esc(r.interestRate || '')}</td><td class="num">${esc(r.tenure || '')}</td>
          <td class="num">${Core.inr(Core.num(r.emi))}</td>
          <td><span class="pill ${r.status}">${esc(r.status)}</span></td>
          <td><button class="mini" data-report="${esc(r.id)}">📊 ${t('report')}</button></td>
        </tr>`).join('') : `<tr><td colspan="10" class="empty">No records</td></tr>`;
      $('#jlg-pager').innerHTML = `<button class="mini ghost" ${st.page<=1?'disabled':''} id="jp-prev">◀ Prev</button>
        <span class="muted">Page ${st.page} / ${pages} · ${rows.length}</span>
        <button class="mini ghost" ${st.page>=pages?'disabled':''} id="jp-next">Next ▶</button>`;
      const pv=$('#jp-prev'), nx=$('#jp-next');
      if(pv) pv.onclick=()=>{st.page--;draw();}; if(nx) nx.onclick=()=>{st.page++;draw();};
      $('#jlg-body').querySelectorAll('[data-report]').forEach((b)=>b.onclick=(e)=>{e.stopPropagation();this.report(b.dataset.report);});
      $('#jlg-body').querySelectorAll('tr[data-detail]').forEach((tr)=>tr.onclick=()=>this.loanDetail(tr.dataset.detail, draw));
    };
    v.innerHTML = `
      <div class="pagehead"><h2>${t('loanRecords')} <span id="jlg-count" class="muted"></span></h2>
        <button id="jlg-xls" class="mini" style="background:#059669">⬇ ${t('excel')}</button></div>
      <div class="card filters">
        <input id="jf-name" placeholder="${t('customer')}"/>
        <input id="jf-loan" placeholder="${t('loanNo')}"/>
        <input id="jf-aad" placeholder="${t('aadhaar')}"/>
        <select id="jf-center"><option value="">${t('center')}: All</option>${centers.map((c)=>`<option value="${esc(c.centerNumber)}">${esc(c.centerNumber)} — ${esc(c.centerName)}</option>`).join('')}</select>
        <select id="jf-day"><option value="">${t('collectionDay')}: All</option>${Core.COLLECTION_DAYS.map((d)=>`<option>${d}</option>`).join('')}</select>
        <select id="jf-status"><option value="">${t('status')}: All</option><option>Active</option><option>Closed</option><option>Overdue</option></select>
        <input id="jf-min" placeholder="${t('amtMin')}" inputmode="decimal"/>
        <input id="jf-max" placeholder="${t('amtMax')}" inputmode="decimal"/>
      </div>
      <div class="dtable"><table class="dtbl">
        <thead><tr><th>${t('loanNo')}</th><th>${t('customer')}</th><th>${t('centerNo')}</th><th>${t('aadhaar')}</th><th>${t('loanAmt')}</th><th>${t('interest')}</th><th>${t('tenure')}</th><th>${t('emi')}</th><th>${t('status')}</th><th>${t('report')}</th></tr></thead>
        <tbody id="jlg-body"></tbody>
      </table></div>
      <div class="pager" id="jlg-pager"></div>`;
    const bind=(id,k)=>{ $('#'+id).oninput=(e)=>{st[k]=e.target.value;st.page=1;draw();}; };
    bind('jf-name','name');bind('jf-loan','loanNo');bind('jf-aad','aadhaar');bind('jf-min','amtMin');bind('jf-max','amtMax');
    $('#jf-center').onchange=(e)=>{st.center=e.target.value;st.page=1;draw();};
    $('#jf-day').onchange=(e)=>{st.day=e.target.value;st.page=1;draw();};
    $('#jf-status').onchange=(e)=>{st.status=e.target.value;st.page=1;draw();};
    $('#jlg-xls').onclick=()=>this.exportXlsx('Loans', current.map((r)=>({'Loan No':r.loanNumber,Customer:r.member,Aadhaar:r.aadhaar,Center:r.centerName,'Loan Amt':Core.num(r.loanAmt),'Interest %':r.interestRate,Tenure:r.tenure,'Collection Day':r.collectionDay,'Weekly EMI':Core.num(r.emi),Nominee:r.nomineeName,Relation:r.nomineeRelation,Status:r.status})));
    draw();
  },

  loanDetail(id, after) {
    const r = Core.get('loans', id); if (!r) return;
    const admin = Core.Auth.isAdmin;
    const layer = $('#layer');
    layer.innerHTML = `
      <div class="modal-bg"></div>
      <div class="modal" style="max-width:520px">
        <div class="modal-head"><b>${esc(r.loanNumber)}</b><button class="mini" id="d-close">✕</button></div>
        <div class="sum">
          <div><span>${t('customer')}</span>${esc(r.member)}</div>
          <div><span>${t('center')}</span>${esc(r.centerName || '')}</div>
          <div><span>${t('aadhaar')}</span>${esc(r.aadhaar || '-')}</div>
          <div><span>${t('loanAmt')}</span>₹ ${Core.inr(Core.num(r.loanAmt))}</div>
          <div><span>${t('interest')}</span>${esc(r.interestRate || '')}</div>
          <div><span>${t('tenure')}</span>${esc(r.tenure || '')}</div>
          <div><span>${t('collectionDay')}</span>${esc(r.collectionDay || '')}</div>
          <div><span>${t('emi')}</span>₹ ${Core.inr(Core.num(r.emi))}</div>
          <div><span>${t('nominee')}</span>${esc(r.nomineeName || '-')}</div>
          <div><span>${t('relation')}</span>${esc(r.nomineeRelation || '-')}</div>
          <div><span>${t('address')}</span>${esc(r.address || '-')}</div>
          <div><span>${t('status')}</span>${esc(r.status)}</div>
        </div>
        <label>${t('status')}</label>
        <div class="row-btn">
          <button class="mini" data-st="Active" style="background:#059669">${t('active')}</button>
          <button class="mini" data-st="Closed" style="background:#6B7280">${t('closed')}</button>
          <button class="mini" data-st="Overdue" style="background:#DC2626">${t('overdue')}</button>
        </div>
        ${admin ? `<button class="mini del" id="d-del" style="margin-top:10px">🗑 ${t('del')}</button>` : ''}
      </div>`;
    const close = () => { layer.innerHTML = ''; after && after(); };
    $('#d-close').onclick = close;
    layer.querySelectorAll('[data-st]').forEach((b) => b.onclick = () => {
      Core.saveRec('loans', { ...r, status: b.dataset.st }); toast('Status: ' + b.dataset.st); close();
    });
    if (admin) $('#d-del').onclick = () => { if (confirm('Delete loan ' + r.loanNumber + '?')) { Core.removeRec('loans', id); toast('Deleted'); close(); } };
  },

  async exportXlsx(name, rows) {
    if (!rows.length) return toast('Nothing to export');
    if (!window.XLSX) return toast('Excel library not loaded');
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, ws, name);
    const b64 = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
    await saveOrShare(name + '.xlsx', b64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    toast('Excel ready');
  },

  /* ---------------- collection report ---------------- */
  report(loanId) {
    const loan = Core.get('loans', loanId); if (!loan) return;
    const admin = Core.Auth.isAdmin;
    const layer = $('#layer');
    const render = () => {
      const sched = Core.loanSchedule(loan);
      const collected = Core.totalCollected(loan.id);
      const totalDue = Core.num(loan.emi) * (parseInt(loan.tenure || 0, 10) || 0);
      const today = new Date();
      layer.innerHTML = `
        <div class="modal-bg"></div>
        <div class="modal">
          <div class="modal-head">
            <b>${t('weekly')} — ${esc(loan.loanNumber)}</b>
            <div><button class="mini" id="r-print">🖨 ${t('print')}</button> <button class="mini" id="r-close">✕</button></div>
          </div>
          <div class="sum">
            <div><span>${t('customer')}</span>${esc(loan.member)}</div>
            <div><span>${t('center')}</span>${esc(loan.centerName || loan.centerNumber || '')}</div>
            <div><span>${t('emi')}</span>₹ ${Core.inr(Core.num(loan.emi))}</div>
            <div><span>${t('collected')}</span>₹ ${Core.inr(collected)}</div>
            <div><span>Balance</span>₹ ${Core.inr(Math.max(totalDue - collected, 0))}</div>
          </div>
          <div class="table">
            <div class="tr th"><div>${t('week')}</div><div>${t('due')}</div><div>${t('emi')}</div><div>${t('collected')}</div><div>${t('status')}</div><div></div></div>
            <div id="r-body">${sched.map((w) => {
              const saved = w.saved; const paid = saved ? Core.num(saved.amountPaid) : 0;
              const stt = saved ? (paid > 0 ? 'Paid' : 'Nil') : (w.dueObj < today ? 'Overdue' : 'Pending');
              const editable = !saved || admin;
              return `<div class="tr">
                <div>${w.weekNo}</div><div>${w.dueDate}</div><div class="num">${Core.inr(w.amountDue)}</div>
                <div><input class="wk" data-wk="${w.weekNo}" data-due="${w.dueDate}" value="${saved ? Core.inr(paid) : ''}" ${editable ? '' : 'readonly'} inputmode="decimal"/></div>
                <div><span class="pill ${stt}">${stt}</span></div>
                <div>${editable ? `<button class="mini save" data-save="${w.weekNo}">💾</button>` : `<span class="muted sm">🔒 ${t('adminOnly')}</span>`}</div>
              </div>`;
            }).join('')}</div>
          </div>
        </div>`;
      $('#r-close').onclick = () => layer.innerHTML = '';
      $('#r-print').onclick = () => this.reportPDF(loan);
      layer.querySelectorAll('[data-save]').forEach((b) => b.onclick = () => {
        const wk = +b.dataset.save; const inp = layer.querySelector(`.wk[data-wk="${wk}"]`);
        const amt = Core.num(inp.value); const due = inp.dataset.due;
        if (amt <= 0 && !confirm('Save week ' + wk + ' with ₹0?')) return;
        Core.saveCollection(loan, wk, due, Core.num(loan.emi), amt);
        toast('Week ' + wk + ' saved'); render();
      });
    };
    render();
  },

  async reportPDF(loan) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const W = doc.internal.pageSize.getWidth();
    try { doc.addImage(window.LOGO_DATA_URL, 'PNG', W / 2 - 23, 10, 46, 23); } catch (e) {}
    doc.setFontSize(16); doc.setTextColor('#0E1B3A');
    doc.text(t('appName'), W / 2, 40, { align: 'center' });
    doc.setFontSize(11); doc.setTextColor('#3B6FE0');
    doc.text(t('weekly'), W / 2, 47, { align: 'center' });

    const collected = Core.totalCollected(loan.id);
    const totalDue = Core.num(loan.emi) * (parseInt(loan.tenure || 0, 10) || 0);
    doc.autoTable({
      startY: 52, theme: 'grid', styles: { fontSize: 9 },
      body: [
        ['Loan No', loan.loanNumber, 'Customer', loan.member],
        ['Center', (loan.centerName || loan.centerNumber || '-'), 'Collection Day', loan.collectionDay || '-'],
        ['Loan Amount', 'Rs. ' + Core.inr(Core.num(loan.loanAmt)), 'Weekly EMI', 'Rs. ' + Core.inr(Core.num(loan.emi))],
        ['Tenure', (loan.tenure || 0) + ' weeks', 'Interest %', String(loan.interestRate || '')],
        ['Total Collected', 'Rs. ' + Core.inr(collected), 'Balance', 'Rs. ' + Core.inr(Math.max(totalDue - collected, 0))],
        ['Address', loan.address || '-', 'Status', loan.status || ''],
      ],
      columnStyles: { 0: { fontStyle: 'bold', fillColor: [238, 240, 251] }, 2: { fontStyle: 'bold', fillColor: [238, 240, 251] } },
    });
    const today = new Date();
    const rows = Core.loanSchedule(loan).map((w) => {
      const saved = w.saved; const paid = saved ? Core.num(saved.amountPaid) : 0;
      const stt = saved ? (paid > 0 ? 'Paid' : 'Nil') : (w.dueObj < today ? 'Overdue' : 'Pending');
      return [w.weekNo, w.dueDate, Core.inr(w.amountDue), saved ? Core.inr(paid) : '-',
        saved && saved.updatedAt ? Core.fmtDMY(new Date(saved.updatedAt)) : '-', stt];
    });
    doc.autoTable({
      startY: doc.lastAutoTable.finalY + 6, theme: 'grid', styles: { fontSize: 8.5 },
      head: [['Week', 'Due Date', 'EMI Due', 'Collected', 'Paid Date', 'Status']],
      headStyles: { fillColor: [14, 27, 58] },
      alternateRowStyles: { fillColor: [238, 240, 251] },
      body: rows,
    });
    doc.setFontSize(8); doc.setTextColor('#6B7280');
    doc.text('Generated ' + Core.fmtDMY(today) + ' • computer-generated report',
      14, doc.lastAutoTable.finalY + 8);
    const b64 = doc.output('datauristring').split(',')[1];
    await saveOrShare('CollectionReport_' + loan.loanNumber + '.pdf', b64, 'application/pdf');
    toast('PDF ready');
  },

  /* ---------------- centers ---------------- */
  centerNew(v) {
    const staff = Core.all('users');
    v.innerHTML = `
      <h2>${t('newCenter')}</h2>
      <div class="card form">
        <label>${t('centerNo')}</label><input value="${esc(Core.nextCenterNumber())}" readonly class="ro"/>
        <div class="muted sm">(generated automatically on save)</div>
        <label>${t('centerName')}</label><input id="c-name"/>
        <label>${t('staff')}</label>
        <select id="c-staff">${staff.length ? staff.map((u)=>`<option value="${esc(u.id)}">${esc(u.name)} (${esc(u.username||'')})</option>`).join('') : `<option value="">(no staff)</option>`}</select>
        <div class="row-btn"><button id="c-save" class="btn-accent">${t('save')}</button></div>
      </div>`;
    $('#c-save').onclick = () => {
      const name = $('#c-name').value.trim(); if (!name) return toast('Center name required');
      const sid = $('#c-staff').value; const su = Core.get('users', sid);
      Core.saveRec('centers', { centerNumber: Core.nextCenterNumber(), centerName: name, staffId: sid, staffName: su ? su.name : '' });
      toast('Center saved'); this.centerNew(v);
    };
  },

  centerRecords(v) {
    const admin = Core.Auth.isAdmin;
    const st = this._cf || (this._cf = { num: '', name: '', page: 1 });
    const PER = 12; let current = [];
    const draw = () => {
      let rows = Core.all('centers').sort((a, b) => (a.centerNumber > b.centerNumber ? -1 : 1));
      rows = rows.filter((r) =>
        (!st.num || (r.centerNumber || '').toLowerCase().includes(st.num.toLowerCase())) &&
        (!st.name || (r.centerName || '').toLowerCase().includes(st.name.toLowerCase())));
      current = rows;
      const pages = Math.max(1, Math.ceil(rows.length / PER)); if (st.page > pages) st.page = pages;
      const slice = rows.slice((st.page - 1) * PER, st.page * PER);
      $('#c-count').textContent = `(${rows.length})`;
      $('#c-body').innerHTML = slice.length ? slice.map((r) => `
        <tr><td>${esc(r.centerNumber)}</td><td>${esc(r.centerName)}</td><td>${esc(r.staffName || '-')}</td>
        <td>${esc(r.createdBy || '')}</td><td>${r.createdAt ? Core.fmtDMY(new Date(r.createdAt)) : ''}</td>
        <td>${admin ? `<button class="mini del" data-del="${esc(r.id)}">🗑</button>` : ''}</td></tr>`).join('')
        : `<tr><td colspan="6" class="empty">No centers</td></tr>`;
      $('#c-pager').innerHTML = `<button class="mini ghost" ${st.page<=1?'disabled':''} id="cp-prev">◀</button><span class="muted">Page ${st.page} / ${pages}</span><button class="mini ghost" ${st.page>=pages?'disabled':''} id="cp-next">▶</button>`;
      const pv=$('#cp-prev'),nx=$('#cp-next'); if(pv)pv.onclick=()=>{st.page--;draw();}; if(nx)nx.onclick=()=>{st.page++;draw();};
      $('#c-body').querySelectorAll('[data-del]').forEach((b)=>b.onclick=()=>{ if(confirm('Delete center?')){Core.removeRec('centers',b.dataset.del);draw();} });
    };
    v.innerHTML = `
      <div class="pagehead"><h2>${t('centerRecords')} <span id="c-count" class="muted"></span></h2>
        <button id="c-xls" class="mini" style="background:#059669">⬇ ${t('excel')}</button></div>
      <div class="card filters"><input id="cf-num" placeholder="${t('centerNo')}"/><input id="cf-name" placeholder="${t('centerName')}"/></div>
      <div class="dtable"><table class="dtbl">
        <thead><tr><th>${t('centerNo')}</th><th>${t('centerName')}</th><th>${t('staff')}</th><th>Created By</th><th>Created At</th><th></th></tr></thead>
        <tbody id="c-body"></tbody></table></div>
      <div class="pager" id="c-pager"></div>`;
    $('#cf-num').oninput=(e)=>{st.num=e.target.value;st.page=1;draw();};
    $('#cf-name').oninput=(e)=>{st.name=e.target.value;st.page=1;draw();};
    $('#c-xls').onclick=()=>this.exportXlsx('Centers', current.map((r)=>({'Center No':r.centerNumber,'Center Name':r.centerName,Staff:r.staffName})));
    draw();
  },

  /* ---------------- users (admin) ---------------- */
  usersView(v) {
    if (!Core.Auth.isAdmin) { v.innerHTML = `<div class="empty">Admins only.</div>`; return; }
    const roles = ['Admin', 'Manager', 'Staff', 'Accountant', 'Viewer'];
    const draw = async () => {
      let list = [];
      try { list = await Sync.listUsers(); }
      catch (e) { list = Core.all('users').map((u) => ({ id: u.id, name: u.name, username: u.username, role: u.role })); }
      $('#u-body').innerHTML = list.length ? list.map((u) => `
        <div class="tr"><div>${esc(u.name)}</div><div>${esc(u.username || '')}</div>
        <div>${esc(u.role)}</div>
        <div><button class="mini" data-role="${esc(u.id)}" data-cur="${esc(u.role)}">${t('role')}</button></div></div>`).join('')
        : `<div class="empty">No users</div>`;
      $('#u-body').querySelectorAll('[data-role]').forEach((b) => b.onclick = async () => {
        const nr = prompt('Role (' + roles.join('/') + '):', b.dataset.cur); if (!nr || !roles.includes(nr)) return;
        try { await Sync.updateUser(b.dataset.role, { role: nr }); toast('Role updated'); Sync.run(); draw(); }
        catch (e) { toast(e.message || 'Failed'); }
      });
    };
    v.innerHTML = `
      <h2>${t('users')}</h2>
      <div class="card form">
        <b>${t('addUser')}</b>
        <label>${t('fullName')}</label><input id="u-name"/>
        <label>${t('username')}</label><input id="u-user"/>
        <label>${t('password')}</label><input id="u-pass" type="password"/>
        <label>${t('role')}</label><select id="u-role">${roles.map((r) => `<option ${r === 'Staff' ? 'selected' : ''}>${r}</option>`).join('')}</select>
        <div class="row-btn"><button id="u-add" class="btn-accent">${t('addUser')}</button></div>
      </div>
      <div class="card table" style="margin-top:12px">
        <div class="tr th" style="grid-template-columns:1.4fr 1.4fr 1fr .8fr"><div>${t('fullName')}</div><div>${t('username')}</div><div>${t('role')}</div><div></div></div>
        <div id="u-body"></div>
      </div>`;
    document.querySelectorAll('#u-body .tr, #view .table .tr').forEach(() => {});
    $('#u-add').onclick = async () => {
      const n = $('#u-name').value.trim(), u = $('#u-user').value.trim(), p = $('#u-pass').value, r = $('#u-role').value;
      if (!u || !p) return toast('Username and password required');
      try { await Sync.createUser(n || u, u, p, r); toast('User added'); $('#u-name').value = $('#u-user').value = $('#u-pass').value = ''; Sync.run(); draw(); }
      catch (e) { toast(e.message || 'Failed'); }
    };
    // fix users table row columns
    const style = document.createElement('style'); style.textContent = '#u-body .tr{grid-template-columns:1.4fr 1.4fr 1fr .8fr}'; v.appendChild(style);
    draw();
  },

  /* ---------------- profile ---------------- */
  profileView(v) {
    v.innerHTML = `
      <h2>${t('profile')}</h2>
      <div class="card form">
        <div><span class="muted">${t('fullName')}:</span> <b>${esc(Core.Auth.user.name)}</b></div>
        <div><span class="muted">${t('role')}:</span> <b>${esc(Core.Auth.role)}</b></div>
        <hr style="border:0;border-top:1px solid var(--line);margin:14px 0"/>
        <b>${t('changePw')}</b>
        <label>${t('oldPw')}</label><input id="p-old" type="password"/>
        <label>${t('newPw')}</label><input id="p-new" type="password"/>
        <div class="row-btn"><button id="p-save" class="btn-accent">${t('changePw')}</button></div>
      </div>`;
    $('#p-save').onclick = async () => {
      const o = $('#p-old').value, n = $('#p-new').value;
      if (!n) return toast('Enter new password');
      try { await Sync.changePassword(o, n); toast('Password changed'); $('#p-old').value = $('#p-new').value = ''; }
      catch (e) { toast(e.message || 'Failed'); }
    };
  },
  /* ---------------- dashboard ---------------- */
  _todayRange() {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    return [d.getTime(), d.getTime() + 86400000];
  },

  dashboardView(v) {
    const loans = Core.all('loans'), centers = Core.all('centers'), weeks = Core.all('weeks');
    const disbursed = loans.reduce((s, l) => s + Core.num(l.loanAmt), 0);
    const collected = weeks.reduce((s, w) => s + Core.num(w.amountPaid), 0);
    const totalDue = loans.reduce((s, l) => s + Core.num(l.emi) * (parseInt(l.tenure || 0, 10) || 0), 0);
    const outstanding = Math.max(totalDue - collected, 0);
    const active = loans.filter((l) => l.status === 'Active').length;
    const overdue = loans.filter((l) => l.status === 'Overdue').length;
    const [t0, t1] = this._todayRange();
    const todayCol = weeks.filter((w) => w.updatedAt >= t0 && w.updatedAt < t1)
      .reduce((s, w) => s + Core.num(w.amountPaid), 0);

    // collections by center
    const byCenter = {};
    weeks.forEach((w) => {
      const ln = Core.get('loans', w.loanId); if (!ln) return;
      const k = ln.centerName || ln.centerNumber || '—';
      byCenter[k] = (byCenter[k] || 0) + Core.num(w.amountPaid);
    });
    const centerRows = Object.entries(byCenter).sort((a, b) => b[1] - a[1]);
    const recent = loans.slice().sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)).slice(0, 6);

    const card = (label, val, color) =>
      `<div class="dcard"><div class="dval" style="color:${color || 'var(--brand)'}">${val}</div><div class="dlbl">${label}</div></div>`;

    v.innerHTML = `
      <h2>${t('dashboard')}</h2>
      <div class="dgrid">
        ${card(t('totalCenters'), centers.length)}
        ${card(t('activeLoans'), active)}
        ${card(t('disbursed'), '₹ ' + Core.inr(disbursed))}
        ${card(t('collected'), '₹ ' + Core.inr(collected), '#059669')}
        ${card(t('outstanding'), '₹ ' + Core.inr(outstanding), '#DC2626')}
        ${card(t('todayCollection'), '₹ ' + Core.inr(todayCol), '#14B8A6')}
        ${card(t('overdue'), overdue, '#DC2626')}
        ${card(t('totalLoans'), loans.length)}
      </div>
      <div class="dash-bottom">
      <div class="card" style="padding:14px">
        <b>${t('collectionsByCenter')}</b>
        ${centerRows.length ? centerRows.map(([k, val]) => `
          <div class="brow"><span>${esc(k)}</span><b>₹ ${Core.inr(val)}</b></div>`).join('')
          : `<div class="muted" style="padding:8px 0">—</div>`}
      </div>
      <div class="card" style="padding:14px">
        <b>${t('recentLoans')}</b>
        ${recent.length ? recent.map((l) => `
          <div class="brow"><span>${esc(l.loanNumber)} · ${esc(l.member)}</span><b>₹ ${Core.inr(Core.num(l.loanAmt))}</b></div>`).join('')
          : `<div class="muted" style="padding:8px 0">—</div>`}
      </div>
      </div>`;
  },

  /* ---------------- EOD (end of day) ---------------- */
  /* ---------------- staff collection records ---------------- */
  staffCollectionView(v) {
    const staffList = [...new Set(Core.all('centers').map((c) => c.staffName).filter(Boolean))];
    const st = this._sc || (this._sc = { staff: '', day: '', week: '', status: '', page: 1 });
    const PER = 15; let current = [];
    const centerStaff = {}; Core.all('centers').forEach((c) => { centerStaff[c.centerNumber] = c.staffName || ''; });
    const today = new Date(); today.setHours(0,0,0,0);
    const rowsAll = () => Core.all('loans').map((l) => {
      const tenure = parseInt(l.tenure || 0, 10) || 0; const emi = Core.num(l.emi);
      const start = Core.parseDMY(l.loanDate);
      const cur = Math.max(1, Math.min(tenure || 1, Math.floor((today - start) / (7 * 86400000)) + 1));
      const saved = Core.all('weeks').filter((w) => w.loanId === l.id && Core.num(w.amountPaid) > 0);
      const collected = saved.reduce((s2, w) => s2 + Core.num(w.amountPaid), 0);
      return { l, staff: centerStaff[l.centerNumber] || '', cur, tenure, weeksCollected: saved.length,
        remaining: Math.max(emi * tenure - collected, 0) };
    });
    const draw = () => {
      let rows = rowsAll().filter((x) =>
        (!st.staff || x.staff === st.staff) &&
        (!st.day || x.l.collectionDay === st.day) &&
        (!st.week || String(x.cur) === String(st.week)) &&
        (!st.status || x.l.status === st.status));
      current = rows;
      const pages = Math.max(1, Math.ceil(rows.length / PER)); if (st.page > pages) st.page = pages;
      const slice = rows.slice((st.page - 1) * PER, st.page * PER);
      $('#sc-count').textContent = `(${rows.length})`;
      $('#sc-body').innerHTML = slice.length ? slice.map((x) => `
        <tr><td>${esc(x.l.member)}</td><td>${esc(x.l.centerName || x.l.centerNumber || '')}</td><td>${esc(x.staff || '-')}</td>
        <td>${esc(x.l.collectionDay || '')}</td><td class="num">${x.cur}</td><td class="num">${x.tenure}</td>
        <td class="num">${x.weeksCollected}</td><td class="num">${Core.inr(x.remaining)}</td>
        <td><span class="pill ${x.l.status}">${esc(x.l.status)}</span></td></tr>`).join('')
        : `<tr><td colspan="9" class="empty">No records</td></tr>`;
      $('#sc-pager').innerHTML = `<button class="mini ghost" ${st.page<=1?'disabled':''} id="sp-prev">◀</button><span class="muted">Page ${st.page} / ${pages} · ${rows.length}</span><button class="mini ghost" ${st.page>=pages?'disabled':''} id="sp-next">▶</button>`;
      const pv=$('#sp-prev'),nx=$('#sp-next'); if(pv)pv.onclick=()=>{st.page--;draw();}; if(nx)nx.onclick=()=>{st.page++;draw();};
    };
    v.innerHTML = `
      <div class="pagehead"><h2>${t('staffCollection')} <span id="sc-count" class="muted"></span></h2>
        <button id="sc-pdf" class="mini" style="background:#3B6FE0">🖨 PDF</button></div>
      <div class="card filters">
        <select id="sf-staff"><option value="">${t('staff')}: All</option>${staffList.map((s2)=>`<option>${esc(s2)}</option>`).join('')}</select>
        <select id="sf-day"><option value="">${t('collectionDay')}: All</option>${Core.COLLECTION_DAYS.map((d)=>`<option>${d}</option>`).join('')}</select>
        <input id="sf-week" placeholder="${t('collectionWeek')}" inputmode="numeric"/>
        <select id="sf-status"><option value="">${t('status')}: All</option><option>Active</option><option>Closed</option><option>Overdue</option></select>
      </div>
      <div class="dtable"><table class="dtbl">
        <thead><tr><th>${t('customer')}</th><th>${t('center')}</th><th>${t('staff')}</th><th>${t('collectionDay')}</th><th>${t('weekNo')}</th><th>${t('totalWeeks')}</th><th>${t('weeksCollected')}</th><th>${t('remaining')}</th><th>${t('status')}</th></tr></thead>
        <tbody id="sc-body"></tbody></table></div>
      <div class="pager" id="sc-pager"></div>`;
    $('#sf-staff').onchange=(e)=>{st.staff=e.target.value;st.page=1;draw();};
    $('#sf-day').onchange=(e)=>{st.day=e.target.value;st.page=1;draw();};
    $('#sf-week').oninput=(e)=>{st.week=e.target.value;st.page=1;draw();};
    $('#sf-status').onchange=(e)=>{st.status=e.target.value;st.page=1;draw();};
    $('#sc-pdf').onclick=()=>this.exportXlsx('StaffCollection', current.map((x)=>({Customer:x.l.member,Center:x.l.centerName,Staff:x.staff,'Collection Day':x.l.collectionDay,'Week No':x.cur,'Total Weeks':x.tenure,'Weeks Collected':x.weeksCollected,Remaining:x.remaining,Status:x.l.status})));
    draw();
  },

  // ---- EOD auto calculations (JLG only) ----
  computeEod(dateObj) {
    const loans = Core.all('loans'), weeks = Core.all('weeks');
    const d0 = new Date(dateObj); d0.setHours(0, 0, 0, 0);
    const t0 = d0.getTime(), t1 = t0 + 86400000;
    const wd = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][d0.getDay()];
    let emiExpected = 0, overdue = 0, outstanding = 0;
    loans.forEach((l) => {
      const emi = Core.num(l.emi), tenure = parseInt(l.tenure || 0, 10) || 0;
      const start = Core.parseDMY(l.loanDate), last = Core.addWeeks(start, tenure);
      const coll = weeks.filter((w) => w.loanId === l.id).reduce((s, w) => s + Core.num(w.amountPaid), 0);
      if ((l.status || 'Active') === 'Active' && l.collectionDay === wd && d0 > start && d0 <= last) emiExpected += emi;
      const elapsed = Math.max(0, Math.min(tenure, Math.floor((d0 - start) / (7 * 86400000))));
      overdue += Math.max(elapsed * emi - coll, 0);
      outstanding += Math.max(tenure * emi - coll, 0);
    });
    const emiCollected = weeks.filter((w) => w.updatedAt >= t0 && w.updatedAt < t1).reduce((s, w) => s + Core.num(w.amountPaid), 0);
    const loanDisbursed = loans.filter((l) => (l.createdAt || 0) >= t0 && (l.createdAt || 0) < t1).reduce((s, l) => s + Core.num(l.loanAmt), 0);
    // opening = previous closed/saved day's cash in hand
    const prev = Core.all('eod').map((e) => ({ e, d: Core.parseDMY(e.date) }))
      .filter((x) => x.d < d0).sort((a, b) => b.d - a.d);
    const opening = prev.length ? Core.num(prev[0].e.cashInHand) : 0;
    return { emiExpected, overdue, outstanding, emiCollected, loanDisbursed, opening };
  },

  eodView(v) {
    const tab = this._eodTab || 'entry';
    v.innerHTML = `
      <div class="eodtabs">
        <button data-tab="entry" class="${tab === 'entry' ? 'on' : ''}">EOD Entry</button>
        <button data-tab="history" class="${tab === 'history' ? 'on' : ''}">EOD History</button>
      </div>
      <div id="eod-wrap"></div>`;
    v.querySelectorAll('.eodtabs button').forEach((b) => b.onclick = () => { this._eodTab = b.dataset.tab; this.eodView(v); });
    if (tab === 'history') return this.eodHistory($('#eod-wrap'));
    this.eodEntry($('#eod-wrap'));
  },

  eodEntry(host) {
    const dISO = this._eodDate || new Date().toISOString().slice(0, 10);
    this._eodDate = dISO;
    const dObj = new Date(dISO);
    const dateStr = Core.fmtDMY(dObj);
    const id = 'eod-' + dISO.replace(/-/g, '');
    const existing = Core.get('eod', id);
    const auto = this.computeEod(dObj);
    const st = this._eodS = Object.assign({
      addFund: 0, bankDeposit: 0, expenses: [],
      denom: { 500: 0, 200: 0, 100: 0, 50: 0, 20: 0, 10: 0, 5: 0, 2: 0, 1: 0, coins: 0 },
    }, existing ? {
      addFund: Core.num(existing.addFund), bankDeposit: Core.num(existing.bankDeposit),
      expenses: existing.expenses || [], denom: existing.denom || {},
    } : {});
    const closed = existing && existing.status === 'closed';

    const money = (id2, val, ro) => `<input id="${id2}" class="eodin ${ro ? 'ro' : ''}" ${ro ? 'readonly' : ''} value="${ro ? '₹ ' + Core.inr(val) : (val || '')}" inputmode="decimal"/>`;
    const DEN = [500, 200, 100, 50, 20, 10, 5, 2, 1];

    host.innerHTML = `
      <div class="eodhead">
        <h2>${t('eod')} <span class="eodstatus ${closed ? 'cl' : 'op'}">${closed ? 'CLOSED' : 'OPEN'}</span></h2>
        <input type="date" id="eod-date" value="${dISO}" class="eoddate"/>
      </div>

      <div class="eodsec s1">
        <div class="eodtitle">1 · Expected Collection Summary</div>
        <div class="eodrow"><span>Opening Cash (prev day)</span>${money('a-open', auto.opening, 1)}</div>
        <div class="eodrow"><span>Today's EMI Expected</span>${money('a-emiexp', auto.emiExpected, 1)}</div>
        <div class="eodrow"><span>Overdue Amount</span>${money('a-overdue', auto.overdue, 1)}</div>
        <div class="eodrow tot"><span>Total Expected Collection</span>${money('a-texp', auto.opening + auto.emiExpected + auto.overdue, 1)}</div>
      </div>

      <div class="eodsec s2">
        <div class="eodtitle">2 · Outstanding Summary</div>
        <div class="eodrow tot"><span>Total Outstanding EMI</span>${money('a-out', auto.outstanding, 1)}</div>
      </div>

      <div class="eodgrid2">
        <div class="eodsec s3">
          <div class="eodtitle">3 · Cash In</div>
          <div class="eodrow"><span>EMI Collected (auto)</span>${money('a-coll', auto.emiCollected, 1)}</div>
          <div class="eodrow"><span>Add Fund</span>${money('m-fund', st.addFund)}</div>
          <div class="eodrow tot"><span>Total Cash In</span>${money('a-cashin', 0, 1)}</div>
        </div>
        <div class="eodsec s4">
          <div class="eodtitle">4 · Cash Out</div>
          <div class="eodrow"><span>Loan Disbursed (auto)</span>${money('a-disb', auto.loanDisbursed, 1)}</div>
          <div class="eodrow"><span>Expenses</span><button class="mini" id="m-addexp">+ Add</button></div>
          <div id="exp-list"></div>
          <div class="eodrow"><span>Expenses Total</span>${money('a-exptot', 0, 1)}</div>
          <div class="eodrow"><span>Bank Deposit</span>${money('m-bank', st.bankDeposit)}</div>
          <div class="eodrow tot"><span>Total Cash Out</span>${money('a-cashout', 0, 1)}</div>
        </div>
      </div>

      <div class="eodsec s5">
        <div class="eodtitle">5 · Cash Denomination Tally</div>
        ${DEN.map((d) => `<div class="eodrow den"><span>₹${d} ×</span><input class="dcount" data-d="${d}" value="${st.denom[d] || 0}" inputmode="numeric" style="max-width:90px"/><span class="damt" id="damt-${d}">₹ 0.00</span></div>`).join('')}
        <div class="eodrow den"><span>Coins (amount)</span><input class="dcount" data-d="coins" value="${st.denom.coins || 0}" inputmode="decimal" style="max-width:90px"/><span class="damt" id="damt-coins">₹ 0.00</span></div>
        <div class="eodrow tot"><span>Denomination Total</span>${money('a-dentot', 0, 1)}</div>
      </div>

      <div class="eodsec s6">
        <div class="eodtitle">6 · Cash in Hand</div>
        <div class="cih" id="a-cih">₹ 0.00</div>
      </div>

      <div class="eodbtns">
        <button class="btn-accent" id="eod-save" ${closed ? 'disabled' : ''}>💾 Save EOD</button>
        <button class="btn-brand" id="eod-print">🖨 Print / PDF</button>
        ${!closed ? `<button class="btn-danger" id="eod-close">🔒 Close Day</button>` : `<span class="muted">Day closed — locked.</span>`}
      </div>`;

    const num = (id2) => Core.num(($('#' + id2) || {}).value);
    const setRO = (id2, val) => { const e = $('#' + id2); if (e) e.value = '₹ ' + Core.inr(val); };

    const renderExp = () => {
      $('#exp-list').innerHTML = st.expenses.map((e, i) => `
        <div class="eodrow exp"><input value="${esc(e.name || '')}" data-ei="${i}" class="exp-name" placeholder="name"/><input value="${e.amt || ''}" data-ei="${i}" class="exp-amt" inputmode="decimal" style="max-width:110px"/><button class="mini del" data-ex="${i}">✕</button></div>`).join('');
      $('#exp-list').querySelectorAll('.exp-name').forEach((x) => x.oninput = () => { st.expenses[+x.dataset.ei].name = x.value; });
      $('#exp-list').querySelectorAll('.exp-amt').forEach((x) => x.oninput = () => { st.expenses[+x.dataset.ei].amt = Core.num(x.value); recompute(); });
      $('#exp-list').querySelectorAll('[data-ex]').forEach((x) => x.onclick = () => { st.expenses.splice(+x.dataset.ex, 1); renderExp(); recompute(); });
    };

    const recompute = () => {
      st.addFund = num('m-fund'); st.bankDeposit = num('m-bank');
      let denTot = 0;
      [...host.querySelectorAll('.dcount')].forEach((x) => {
        const d = x.dataset.d; const c = Core.num(x.value); st.denom[d] = c;
        const amt = d === 'coins' ? c : c * Number(d);
        const lbl = $('#damt-' + d); if (lbl) lbl.textContent = '₹ ' + Core.inr(amt);
        denTot += amt;
      });
      const expTot = st.expenses.reduce((s, e) => s + Core.num(e.amt), 0);
      const cashIn = auto.emiCollected + st.addFund;
      const cashOut = auto.loanDisbursed + expTot + st.bankDeposit;
      const cih = auto.opening + cashIn - cashOut;
      setRO('a-cashin', cashIn); setRO('a-exptot', expTot); setRO('a-cashout', cashOut);
      setRO('a-dentot', denTot);
      $('#a-cih').textContent = '₹ ' + Core.inr(cih);
      st._computed = { cashIn, cashOut, expTot, denTot, cih, ...auto, date: dateStr };
    };

    $('#eod-date').onchange = (e) => { this._eodDate = e.target.value; this.eodEntry(host); };
    host.querySelectorAll('#m-fund,#m-bank,.dcount').forEach((x) => x.oninput = recompute);
    $('#m-addexp').onclick = () => { st.expenses.push({ name: '', amt: 0 }); renderExp(); };
    renderExp(); recompute();

    const buildRec = (status) => ({
      id, date: dateStr, opening: auto.opening, emiExpected: auto.emiExpected, overdue: auto.overdue,
      totalExpected: auto.opening + auto.emiExpected + auto.overdue, outstanding: auto.outstanding,
      emiCollected: auto.emiCollected, addFund: st.addFund, totalCashIn: st._computed.cashIn,
      loanDisbursed: auto.loanDisbursed, expenses: st.expenses, expensesTotal: st._computed.expTot,
      bankDeposit: st.bankDeposit, totalCashOut: st._computed.cashOut, denom: st.denom,
      denomTotal: st._computed.denTot, cashInHand: st._computed.cih, status,
    });

    $('#eod-save').onclick = () => { Core.saveRec('eod', buildRec('open')); toast('EOD saved'); };
    $('#eod-close').onclick = () => { if (confirm('Close the day? Data will be locked.')) { Core.saveRec('eod', buildRec('closed')); toast('Day closed'); this.eodEntry(host); } };
    $('#eod-print').onclick = () => this.eodPDF(buildRec(closed ? 'closed' : 'open'));
  },

  eodHistory(host) {
    const f = this._eodHF || (this._eodHF = { from: '', to: '' });
    let rows = Core.all('eod').sort((a, b) => Core.parseDMY(b.date) - Core.parseDMY(a.date));
    if (f.from) rows = rows.filter((r) => Core.parseDMY(r.date) >= new Date(f.from));
    if (f.to) rows = rows.filter((r) => Core.parseDMY(r.date) <= new Date(f.to));
    host.innerHTML = `
      <div class="pagehead"><h2>EOD History</h2>
        <div class="hbtns"><input type="date" id="eh-from" value="${f.from}" class="eoddate"/><input type="date" id="eh-to" value="${f.to}" class="eoddate"/><button class="mini ghost" id="eh-clear">Clear</button></div></div>
      <div class="card eodtable">
        <div class="etr eth"><div>Date</div><div>Opening</div><div>Expected</div><div>Cash In</div><div>Cash Out</div><div>In Hand</div><div>Outstanding</div><div>Status</div></div>
        ${rows.length ? rows.map((r) => `
          <div class="etr">
            <div>${esc(r.date)}</div><div>${Core.inr(Core.num(r.opening))}</div>
            <div>${Core.inr(Core.num(r.totalExpected))}</div><div>${Core.inr(Core.num(r.totalCashIn))}</div>
            <div>${Core.inr(Core.num(r.totalCashOut))}</div><div style="color:#059669">${Core.inr(Core.num(r.cashInHand))}</div>
            <div style="color:#DC2626">${Core.inr(Core.num(r.outstanding))}</div>
            <div><span class="pill ${r.status === 'closed' ? 'Closed' : 'Active'}">${r.status === 'closed' ? '🔒 Closed' : 'Open'}</span></div>
          </div>`).join('') : `<div class="empty">No EOD records</div>`}
      </div>`;
    $('#eh-from').onchange = (e) => { f.from = e.target.value; this.eodHistory(host); };
    $('#eh-to').onchange = (e) => { f.to = e.target.value; this.eodHistory(host); };
    $('#eh-clear').onclick = () => { f.from = ''; f.to = ''; this.eodHistory(host); };
  },

  async eodPDF(rec) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: 'mm', format: 'a4' });
    const W = doc.internal.pageSize.getWidth();
    try { doc.addImage(window.LOGO_DATA_URL, 'PNG', W / 2 - 23, 10, 46, 23); } catch (x) {}
    doc.setFontSize(16); doc.setTextColor('#0E1B3A'); doc.text(t('appName'), W / 2, 40, { align: 'center' });
    doc.setFontSize(12); doc.setTextColor('#3B6FE0'); doc.text('End of Day — ' + rec.date, W / 2, 47, { align: 'center' });
    const R = (k) => 'Rs. ' + Core.inr(Core.num(rec[k]));
    doc.autoTable({
      startY: 52, theme: 'grid', styles: { fontSize: 9.5 },
      body: [
        ['Opening Cash', R('opening'), 'EMI Collected', R('emiCollected')],
        ['Today EMI Expected', R('emiExpected'), 'Add Fund', R('addFund')],
        ['Overdue', R('overdue'), 'Total Cash In', R('totalCashIn')],
        ['Total Expected', R('totalExpected'), 'Loan Disbursed', R('loanDisbursed')],
        ['Outstanding', R('outstanding'), 'Expenses', R('expensesTotal')],
        ['', '', 'Bank Deposit', R('bankDeposit')],
        ['', '', 'Total Cash Out', R('totalCashOut')],
        ['CASH IN HAND', R('cashInHand'), 'Status', (rec.status || 'open').toUpperCase()],
      ],
      columnStyles: { 0: { fontStyle: 'bold', fillColor: [238, 240, 251] }, 2: { fontStyle: 'bold', fillColor: [238, 240, 251] } },
    });
    if ((rec.expenses || []).length) {
      doc.autoTable({ startY: doc.lastAutoTable.finalY + 6, theme: 'grid', styles: { fontSize: 9 },
        head: [['Expense', 'Amount (Rs.)']], headStyles: { fillColor: [14, 27, 58] },
        body: rec.expenses.map((e) => [e.name || '-', Core.inr(Core.num(e.amt))]) });
    }
    doc.setFontSize(8); doc.setTextColor('#6B7280');
    doc.text('Generated ' + Core.fmtDMY(new Date()) + ' • ' + t('appName'), 14, doc.lastAutoTable.finalY + 8);
    const b64 = doc.output('datauristring').split(',')[1];
    await saveOrShare('EOD_' + rec.date + '.pdf', b64, 'application/pdf');
    toast('EOD PDF ready');
  },
};

window.UI = UI;
